# DeathDimension V3.1

Source plugin Paper 1.21.11 / Java 21.

## Changes in 3.1
- Creates a separate empty world named `DeathDimensionVoid` with an empty chunk generator.
- Sends punished players to configurable coordinates (default X=0.5, Y=100, Z=0.5), not the main-world spawn.
- Extends the death cinematic to 7 seconds by default.
- Adds three rotating blue/purple particle rings around the player's body.
- Adds soul, portal, witch particles and a visual lightning strike.
- Keeps the punishment timer running while the player is offline.

## Build
Run `mvn clean package` with Java 21 and Maven. Output: `target/DeathDimension-V3.jar`.

## Install
Upload the built JAR to `plugins/`, then restart the Paper server. The plugin creates `DeathDimensionVoid` automatically on first startup. The return world defaults to `world`.

## Commands
- `/dd status`
- `/dd reload`
- `/dd release <player>` (admin)

## Important
This is an updated source build and still needs testing on a backup server. If a world named `DeathDimensionVoid` already exists and contains terrain, back it up and remove/rename that world while the server is stopped before testing, so the empty generator can create a fresh void world.
