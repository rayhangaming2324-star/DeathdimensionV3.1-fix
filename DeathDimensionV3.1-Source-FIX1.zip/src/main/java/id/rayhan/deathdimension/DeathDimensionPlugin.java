package id.rayhan.deathdimension;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.Difficulty;
import org.bukkit.GameRule;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.util.UUID;

public final class DeathDimensionPlugin extends JavaPlugin implements Listener {
    private File dataFile;
    private YamlConfiguration data;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadData();
        Bukkit.getPluginManager().registerEvents(this, this);
        createVoidWorld();
        getLogger().info("DeathDimension V3.1 aktif.");
        for (Player player : Bukkit.getOnlinePlayers()) {
            Bukkit.getScheduler().runTaskLater(this, () -> enforcePunishment(player), 1L);
        }
    }

    @Override
    public void onDisable() {
        saveData();
    }

    private void loadData() {
        dataFile = new File(getDataFolder(), "data.yml");
        if (!dataFile.exists()) {
            try {
                getDataFolder().mkdirs();
                dataFile.createNewFile();
            } catch (IOException ex) {
                getLogger().severe("Tidak bisa membuat data.yml: " + ex.getMessage());
            }
        }
        data = YamlConfiguration.loadConfiguration(dataFile);
    }

    // Creates a genuinely empty world: chunks contain air, not terrain.
    private World createVoidWorld() {
        String worldName = getConfig().getString("worlds.death-dimension", "DeathDimensionVoid");
        World existing = Bukkit.getWorld(worldName);
        if (existing != null) {
            setVoidWorldRules(existing);
            return existing;
        }

        WorldCreator creator = new WorldCreator(worldName);
        creator.generator(new ChunkGenerator() {
            @Override
            public ChunkData generateChunkData(World world, Random random, int x, int z, BiomeGrid biome) {
                return createChunkData(world);
            }
        });

        World world = Bukkit.createWorld(creator);
        if (world != null) {
            setVoidWorldRules(world);
            world.setSpawnLocation(
                (int) getConfig().getDouble("worlds.void-spawn-x", 0.5),
                (int) getConfig().getDouble("worlds.void-spawn-y", 100.0),
                (int) getConfig().getDouble("worlds.void-spawn-z", 0.5)
            );
            getLogger().info("Void world siap: " + worldName);
        } else {
            getLogger().severe("Gagal membuat void world: " + worldName);
        }
        return world;
    }

    private void setVoidWorldRules(World world) {
        world.setDifficulty(Difficulty.PEACEFUL);
        world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        world.setTime(18000L);
        world.setStorm(false);
    }

    @EventHandler
    public void onLethalDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;

        if (event.getCause() == EntityDamageEvent.DamageCause.VOID && isPunished(player.getUniqueId())) {
            event.setCancelled(true);
            return;
        }
        if (isPunished(player.getUniqueId())) {
            event.setCancelled(true);
            return;
        }
        if (event.getFinalDamage() >= player.getHealth()) {
            event.setCancelled(true);
            beginDeathSequence(player);
        }
    }

    private void beginDeathSequence(Player player) {
        UUID id = player.getUniqueId();
        player.setHealth(1.0);
        player.setInvulnerable(true);
        player.setVelocity(player.getVelocity().setY(0.28));
        player.setSwimming(true);

        player.sendTitle(color(getConfig().getString("death.title", "&c&lKAMU MATI")),
            color(getConfig().getString("death.subtitle", "&7Jiwamu telah dibawa ke kehampaan...")),
            0, 100, 15);
        player.playSound(player.getLocation(), Sound.ENTITY_WARDEN_DEATH,
            (float) getConfig().getDouble("death.sound-volume", 1.4),
            (float) getConfig().getDouble("death.sound-pitch", 0.7));

        if (getConfig().getBoolean("effects.blindness", true))
            player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 160, 1, false, false, false));
        if (getConfig().getBoolean("effects.levitation", true))
            player.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, 150, 0, false, false, true));

        new BukkitRunnable() {
            int ticks = 0;
            @Override public void run() {
                if (!player.isOnline()) {
                    player.setInvulnerable(false);
                    cancel();
                    return;
                }

                if (getConfig().getBoolean("effects.particles", true)) {
                    spawnAura(player, ticks);
                }
                if (ticks == 40 && getConfig().getBoolean("effects.lightning-visual", true)) {
                    player.getWorld().strikeLightningEffect(player.getLocation());
                    player.playSound(player.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.8f, 1.4f);
                }

                ticks += 2;
                if (ticks >= getConfig().getInt("death.cinematic-seconds", 7) * 20) {
                    cancel();
                    sendToVoid(player);
                }
            }
        }.runTaskTimer(this, 0L, 2L);
    }

    private void spawnAura(Player player, int tick) {
        Location base = player.getLocation();
        World world = player.getWorld();
        double rotation = tick * 0.16;

        // Three particle rings wrap around the player's full body.
        for (int ring = 0; ring < 3; ring++) {
            double y = 0.25 + ring * 0.62;
            for (int i = 0; i < 12; i++) {
                double angle = rotation + (Math.PI * 2 * i / 12.0) + ring * 0.35;
                double x = Math.cos(angle) * 0.72;
                double z = Math.sin(angle) * 0.72;
                Location point = base.clone().add(x, y, z);
                Color aura = ((i + ring) % 2 == 0) ? Color.fromRGB(65, 150, 255) : Color.fromRGB(155, 55, 255);
                world.spawnParticle(Particle.DUST, point, 1, 0, 0, 0, 0,
                    new Particle.DustOptions(aura, 1.25f));
            }
        }

        Location chest = base.clone().add(0, 0.95, 0);
        world.spawnParticle(Particle.SOUL, chest, 3, 0.35, 0.55, 0.35, 0.015);
        world.spawnParticle(Particle.PORTAL, chest, 5, 0.4, 0.7, 0.4, 0.08);
        world.spawnParticle(Particle.WITCH, chest, 2, 0.35, 0.5, 0.35, 0.01);
    }

    private void sendToVoid(Player player) {
        World destination = createVoidWorld();
        if (destination == null) {
            player.setInvulnerable(false);
            player.sendMessage(color("&cDeathDimension gagal membuat world Void. Periksa console server."));
            return;
        }

        Location voidSpawn = new Location(destination,
            getConfig().getDouble("worlds.void-spawn-x", 0.5),
            getConfig().getDouble("worlds.void-spawn-y", 100.0),
            getConfig().getDouble("worlds.void-spawn-z", 0.5));
        player.teleport(voidSpawn);
        player.setVelocity(player.getVelocity().zero());
        player.setSwimming(false);
        player.setInvulnerable(true);

        long duration = getConfig().getLong("death.punishment-seconds", 10800);
        data.set("players." + player.getUniqueId(), System.currentTimeMillis() + duration * 1000L);
        saveData();

        player.sendMessage(color(getConfig().getString("messages.prefix", "&8[&5DeathDimension&8] "))
            + color(getConfig().getString("messages.sent", "&cKamu telah memasuki Death Dimension!")));
        player.playSound(voidSpawn, Sound.BLOCK_PORTAL_TRAVEL, 1.0f, 0.65f);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTaskLater(this, () -> enforcePunishment(event.getPlayer()), 10L);
    }

    private void enforcePunishment(Player player) {
        long end = data.getLong("players." + player.getUniqueId(), 0L);
        if (end <= 0L) return;
        if (System.currentTimeMillis() >= end) {
            release(player);
            return;
        }

        World world = createVoidWorld();
        if (world != null && player.getWorld() != world) {
            player.teleport(new Location(world,
                getConfig().getDouble("worlds.void-spawn-x", 0.5),
                getConfig().getDouble("worlds.void-spawn-y", 100.0),
                getConfig().getDouble("worlds.void-spawn-z", 0.5)));
        }
        player.setInvulnerable(true);
        player.sendMessage(color(getConfig().getString("messages.prefix", "&8[&5DeathDimension&8] "))
            + color(getConfig().getString("messages.remaining", "&eWaktu hukuman tersisa: &f%time%")
            .replace("%time%", formatDuration(end - System.currentTimeMillis()))));
        startCountdown(player);
    }

    private void startCountdown(Player player) {
        UUID id = player.getUniqueId();
        new BukkitRunnable() {
            @Override public void run() {
                if (!player.isOnline()) {
                    cancel();
                    return;
                }
                long end = data.getLong("players." + id, 0L);
                if (end <= 0L || System.currentTimeMillis() >= end) {
                    cancel();
                    release(player);
                }
            }
        }.runTaskTimer(this, 20L, 20L);
    }

    private void release(Player player) {
        data.set("players." + player.getUniqueId(), null);
        saveData();
        player.setInvulnerable(false);
        player.removePotionEffect(PotionEffectType.BLINDNESS);
        player.removePotionEffect(PotionEffectType.LEVITATION);
        player.setSwimming(false);

        World world = Bukkit.getWorld(getConfig().getString("worlds.return-world", "world"));
        if (world != null) player.teleport(world.getSpawnLocation());
        player.sendMessage(color(getConfig().getString("messages.prefix", "&8[&5DeathDimension&8] "))
            + color(getConfig().getString("messages.released", "&aKamu telah dikembalikan ke dunia utama.")));
    }

    private boolean isPunished(UUID id) {
        return data.getLong("players." + id, 0L) > System.currentTimeMillis();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("dd")) return false;

        if (args.length == 0 || args[0].equalsIgnoreCase("status")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Gunakan /dd reload atau /dd release <player>.");
                return true;
            }
            long end = data.getLong("players." + player.getUniqueId(), 0L);
            if (end <= System.currentTimeMillis()) {
                player.sendMessage(color(getConfig().getString("messages.no-punishment", "&aKamu tidak sedang menjalani hukuman.")));
            } else {
                player.sendMessage(color(getConfig().getString("messages.remaining", "&eWaktu hukuman tersisa: &f%time%")
                    .replace("%time%", formatDuration(end - System.currentTimeMillis()))));
            }
            return true;
        }

        if (!sender.hasPermission("deathdimension.admin")) {
            sender.sendMessage(color(getConfig().getString("messages.no-permission", "&cKamu tidak memiliki izin.")));
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            sender.sendMessage(color("&aDeathDimension config berhasil dimuat ulang. Restart diperlukan jika nama world Void diubah."));
            return true;
        }
        if (args[0].equalsIgnoreCase("release") && args.length >= 2) {
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(color(getConfig().getString("messages.player-not-found", "&cPemain tidak ditemukan.")));
                return true;
            }
            release(target);
            sender.sendMessage(color(getConfig().getString("messages.admin-release", "&aPemain %player% berhasil dibebaskan.")
                .replace("%player%", target.getName())));
            return true;
        }
        sender.sendMessage(color("&ePerintah: /dd status, /dd reload, /dd release <player>"));
        return true;
    }

    private void saveData() {
        if (data == null || dataFile == null) return;
        try {
            data.save(dataFile);
        } catch (IOException ex) {
            getLogger().severe("Gagal menyimpan data.yml: " + ex.getMessage());
        }
    }

    private String formatDuration(long millis) {
        long seconds = Math.max(0, millis / 1000L);
        return String.format("%02d:%02d:%02d", seconds / 3600, (seconds % 3600) / 60, seconds % 60);
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }
}
